﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyCoffeeApp.Services
{
    public interface IToast
    {
        void MakeToast(string message);
    }
}
