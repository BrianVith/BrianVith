﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TheMovies.Models
{
    public class CinemaMovieShowBooking
    {
        // Implement this!
    }
}
